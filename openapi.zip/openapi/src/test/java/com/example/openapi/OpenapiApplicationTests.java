package com.example.openapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
